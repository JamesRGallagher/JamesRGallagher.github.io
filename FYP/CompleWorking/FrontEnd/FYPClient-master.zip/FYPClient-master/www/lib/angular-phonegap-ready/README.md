# angular-phonegap-ready
Helper to wrap other PhoneGap APIs to ensure that calls happen after `deviceready` is fired.

## License
MIT
